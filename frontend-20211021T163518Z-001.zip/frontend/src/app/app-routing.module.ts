import { AtorUpdateComponent } from './components/Ator/ator-update/ator-update.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from "./views/home/home.component";
import { AtorCrudComponent } from "./views/ator-crud/ator-crud.component";
import {AtorCreateComponent} from './components/Ator/ator-create/ator-create.component'
import { DiretorCreateComponent } from './components/Diretor/diretor-create/diretor-create.component';
import { DiretorCrudComponent } from './views/diretor-crud/diretor-crud.component';
import { TituloCreateComponent } from './components/Titulo/titulo-create/titulo-create.component';
import { TituloCrudComponent } from './views/titulo-crud/titulo-crud.component';
import { ItemCreateComponent } from './components/Item/item-create/item-create.component';
import { ItemCrudComponent } from './views/item-crud/item-crud.component';
import { ClasseCreateComponent } from './components/Classe/classe-create/classe-create.component';
import { ClasseCrudComponent } from './views/classe-crud/classe-crud.component';
import { LocacaoCrudComponent } from './views/locacao-crud/locacao-crud.component';
import { ClienteCrudComponent } from './views/cliente-crud/cliente-crud.component';
import { LocacaoComponent } from './components/AtendimentoCliente/locacao/locacao.component';
import { ClienteComponent } from './components/AtendimentoCliente/cliente/cliente.component';
import { DependenteCreateComponent } from './components/AtendimentoCliente/dependente-create/dependente-create.component';
import { ClasseUpdateComponent } from './components/Classe/classe-update/classe-update.component';
import { DiretorUpdateComponent } from './components/Diretor/diretor-update/diretor-update.component';
import { ItemUpdateComponent } from './components/Item/item-update/item-update.component';
import { TituloUpdateComponent } from './components/Titulo/titulo-update/titulo-update.component';
import { ClienteUpdateComponent } from './components/AtendimentoCliente/cliente/cliente-update/cliente-update.component';
import { LocacaoUpdateComponent } from './components/AtendimentoCliente/locacao/locacao-update/locacao-update.component';
import { ConsultaCrudComponent } from './views/consulta-crud/consulta-crud.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "ator",
    component: AtorCrudComponent
  },
  {
    path: "consulta",
    component: ConsultaCrudComponent
  },
  {
    path: "ator/create",
    component: AtorCreateComponent
  }
  ,
  {
    path: "diretor",
    component: DiretorCrudComponent
  },
  {
    path: "diretor/create",
    component: DiretorCreateComponent
  },
  {
    path: "classe",
    component: ClasseCrudComponent
  },
  {
    path: "classe/create",
    component: ClasseCreateComponent
  },
  {
    path: "item",
    component: ItemCrudComponent
  },
  {
    path: "item/create",
    component: ItemCreateComponent
  },
  {
    path: "titulo",
    component: TituloCrudComponent
  },
  {
    path: "titulo/create",
    component: TituloCreateComponent
  },
  {
    path: "cliente",
    component: ClienteCrudComponent
  },
  {
    path: "cliente/create",
    component: ClienteComponent
  },
  {
    path: "locacao",
    component: LocacaoCrudComponent
  },
  {
    path: "locacao/create",
    component: LocacaoComponent
  },
  {
    path: "cliente/create/dependente",
    component: DependenteCreateComponent
  }, 
  {
    path: "ator/alter/:id",
    component: AtorUpdateComponent
  },
  {
    path: "classe/alter/:id",
    component: ClasseUpdateComponent
  }, 
  {
    path: "diretor/alter/:id",
    component: DiretorUpdateComponent
  },
  {
    path: "item/alter/:id",
    component: ItemUpdateComponent
  },
  {
    path: "titulo/alter/:id",
    component: TituloUpdateComponent
  },
  {
    path: "cliente/alter/:id",
    component: ClienteUpdateComponent
  },
  {
    path: "locacao/alter/:id",
    component: LocacaoUpdateComponent
  },




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
