import { Diretor } from './../diretor.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DiretorService } from '../diretor.service';

@Component({
  selector: 'app-diretor-create',
  templateUrl: './diretor-create.component.html',
  styleUrls: ['./diretor-create.component.css']
})
export class DiretorCreateComponent implements OnInit {

  diretor: Diretor = {
    id:0,
    name: '',
    
  }
  constructor(private diretorService: DiretorService,
    private router: Router) { }

  ngOnInit(): void {
  }
  
  createDiretor(): void {
    this.diretorService.create(this.diretor).subscribe(() => {
      this.diretorService.showMessage('Diretor criado!')
      this.router.navigate(['/diretor'])
    })
        
      }
  
      cancel():void{
          this.router.navigate(['/diretor'])
        
  
      }
}
