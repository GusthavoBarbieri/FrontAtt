import { Diretor } from './diretor.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from "@angular/material/snack-bar";
import { Observable, EMPTY } from "rxjs";
import { map, catchError } from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class DiretorService {

  baseUrl = "http://localhost:4200/ator";

  constructor(private snackBar: MatSnackBar,private http: HttpClient) { }

  showMessage(msg: string): void {
    this.snackBar.open(msg, "X", {
      duration: 3000,
      horizontalPosition: "right",
      verticalPosition: "top",
     
    });
  }

  create(diretor: Diretor): Observable<Diretor> {
    return this.http.post<Diretor>(this.baseUrl, diretor)
  }

  read(): Observable<Diretor[]> {
    return this.http.get<Diretor[]>(this.baseUrl);
  }

  readById(id: string): Observable<Diretor>{
    const url = `${this.baseUrl}/${id}`;
    return this.http.get<Diretor>(url).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  update(diretor: Diretor): Observable<Diretor> {
    const url = `${this.baseUrl}/${diretor.id}`;
    return this.http.put<Diretor>(url, diretor)
    
  }
  
  delete(id: number): Observable<Diretor> {
    const url = `${this.baseUrl}/${id}`;
    return this.http.delete<Diretor>(url).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  errorHandler(e: any): Observable<any> {
    this.showMessage("Ocorreu um erro!");
    return EMPTY;
  }


}
