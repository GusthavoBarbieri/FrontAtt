import { Cliente, ClienteT } from './../cliente.model';
import { Component, OnInit } from '@angular/core';
import { ClienteService } from '../cliente.service';

@Component({
  selector: 'app-cliente-read',
  templateUrl: './cliente-read.component.html',
  styleUrls: ['./cliente-read.component.css']
})
export class ClienteReadComponent implements OnInit {

  cliente: Cliente[] = [];
  displayedColumns = ['id', 'name','sexo','cpf', 'endereco','telefone','ativo','action'];
  ELEMENT_DATA: ClienteT[] = [
    {id: 1,name: 'Hydrogen',sexo:'M',cpf:'111.111.11-11',endereco:'Teste',tel:'999999',ativo:1}
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private clienteService: ClienteService) { 

  }

  ngOnInit(): void {
    this. clienteService.read().subscribe( cliente => {
      this. cliente =  cliente
      //console.log(products)
    })
  }

}
