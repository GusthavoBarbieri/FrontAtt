export interface Locacao {
    id: number
    dataDev:string
    dataPrevista:string
    dataEfetiva:string
    valor:number
    multa:number
}