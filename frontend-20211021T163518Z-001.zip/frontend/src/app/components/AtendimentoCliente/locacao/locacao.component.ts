import { Locacao } from './locacao.model';
import { Component, OnInit } from '@angular/core';
import { LocacaoService } from './locacao.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-locacao',
  templateUrl: './locacao.component.html',
  styleUrls: ['./locacao.component.css']
})
export class LocacaoComponent implements OnInit {

  locacao: Locacao = {
    id:0,
    dataDev: '',
    dataPrevista: '',
    dataEfetiva: '',
    valor:0,
    multa:0,
    
  }
  constructor(private locacaoService: LocacaoService,
    private router: Router) { }

  ngOnInit(): void {
  }
  
  create(): void {
    this.locacaoService.create(this.locacao).subscribe(() => {
      this.locacaoService.showMessage('locacao criado!')
      this.router.navigate(['/locacao'])
    })
        
      }
  
      cancel():void{
          this.router.navigate(['/locacao'])
        
  
      }
}
