import { Locacao } from './../locacao.model';
import { Component, OnInit } from '@angular/core';
import { LocacaoService } from '../locacao.service';

@Component({
  selector: 'app-locacao-read',
  templateUrl: './locacao-read.component.html',
  styleUrls: ['./locacao-read.component.css']
})
export class LocacaoReadComponent implements OnInit {
  locacao: Locacao[] = [];
  displayedColumns = ['id', 'datad','datap','dataf', 'valor','multa','action'];
  ELEMENT_DATA: Locacao[] = [
    {id: 1,dataDev:'18-10-2021',dataEfetiva:'18-10-2021',dataPrevista:'18-10-2021',valor:100,multa:0},
    {id: 2,dataDev:'18-10-2021',dataEfetiva:'18-10-2021',dataPrevista:'18-10-2021',valor:150,multa:0}
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private locacaoService: LocacaoService) { 

  }

  ngOnInit(): void {
    this. locacaoService.read().subscribe( locacao => {
      this. locacao =  locacao
      //console.log(products)
    })
  }

  
}
