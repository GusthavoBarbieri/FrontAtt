import { Classe } from './../classe.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClasseService } from '../classe.service';

@Component({
  selector: 'app-classe-create',
  templateUrl: './classe-create.component.html',
  styleUrls: ['./classe-create.component.css']
})
export class ClasseCreateComponent implements OnInit {

  classe: Classe = {
    id:0,
    name: '',
    valor: 0.0,
    prazoDeDevolucao: 0,
    
  }
  constructor(private classeService: ClasseService,
    private router: Router) { }

  ngOnInit(): void {
  }
  
  createClasse(): void {
   this.classeService.create(this.classe).subscribe(() => {
      this.classeService.showMessage('Classe criada!')
      this.router.navigate(['/classe'])
    })
    //this.router.navigate(['/classe'])  
      }
  
      cancel():void{
          this.router.navigate(['/classe'])
        
  
      }

}
