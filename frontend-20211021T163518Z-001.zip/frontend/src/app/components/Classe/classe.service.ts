import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from "@angular/material/snack-bar";
import { Observable, EMPTY } from "rxjs";
import { map, catchError } from "rxjs/operators";
import { Classe } from './classe.model';

@Injectable({
  providedIn: 'root'
})
export class ClasseService {

  baseUrl = "http://localhost:4200/ator";

  constructor(private snackBar: MatSnackBar,private http: HttpClient) { }

  showMessage(msg: string): void {
    this.snackBar.open(msg, "X", {
      duration: 3000,
      horizontalPosition: "right",
      verticalPosition: "top",
     
    });
  }

  create(classe: Classe): Observable<Classe> {
    return this.http.post<Classe>(this.baseUrl, classe)
  }

  read(): Observable<Classe[]> {
    return this.http.get<Classe[]>(this.baseUrl);
  }


  readById(id: string): Observable<Classe>{
    const url = `${this.baseUrl}/${id}`;
    return this.http.get<Classe>(url).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  update(classe: Classe): Observable<Classe> {
    const url = `${this.baseUrl}/${classe.id}`;
    return this.http.put<Classe>(url, classe)
    
  }
  
  delete(id: number): Observable<Classe> {
    const url = `${this.baseUrl}/${id}`;
    return this.http.delete<Classe>(url).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  errorHandler(e: any): Observable<any> {
    this.showMessage("Ocorreu um erro!");
    return EMPTY;
  }


}
