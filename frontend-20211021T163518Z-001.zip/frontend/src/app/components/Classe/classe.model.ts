
export interface Classe {
    id: number
    name: string
    valor: number
    prazoDeDevolucao: number
}