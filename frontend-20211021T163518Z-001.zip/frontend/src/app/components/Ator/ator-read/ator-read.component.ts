import { Component, OnInit } from '@angular/core';
import { AtorService } from './../ator.service';
import { Ator } from './../ator.model';

@Component({
  selector: 'app-ator-read',
  templateUrl: './ator-read.component.html',
  styleUrls: ['./ator-read.component.css']
})
export class AtorReadComponent implements OnInit {

  ator: Ator[] = [];
  displayedColumns = ['id', 'name','action'];
  ELEMENT_DATA: Ator[] = [
    {id: 1,name: 'Hydrogen'},
    {id: 2,name: 'Helium'},
    {id: 4,name: 'Lithium'},
    {id: 5,name: 'Beryllium'},
    {id: 6,name: 'Boron'},
    {id: 7,name: 'Carbon'},
    {id: 8,name: 'Nitrogen'},
    {id: 9,name: 'Oxygen'},
    {id: 10,name: 'Fluorine'},
    {id: 11,name: 'Neon'},
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private atorService: AtorService) { 

  }

  ngOnInit(): void {
    this.atorService.read().subscribe(ator => {
      this.ator = ator
      //console.log(products)
    })
  }


}
