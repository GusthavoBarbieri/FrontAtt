import { Ator } from './../ator.model';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AtorService } from '../ator.service';

@Component({
  selector: 'app-ator-update',
  templateUrl: './ator-update.component.html',
  styleUrls: ['./ator-update.component.css']
})
export class AtorUpdateComponent implements OnInit {

  ator!: Ator;
  

  constructor(
    private atorService: AtorService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    if(id != null){
      this.atorService.readById(id).subscribe((ator: Ator) => {
        this.ator = ator;
      });
    }
    

  }

  update(): void {
    this.atorService.update(this.ator).subscribe(() => {
      this.atorService.showMessage("ator atualizado com sucesso!");
      this.router.navigate(["/ator"]);
    });

  }

  cancel(): void {
    this.router.navigate(["/ator"]);
  }

}
