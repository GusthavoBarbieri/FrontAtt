import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { AtorRead2DataSource, AtorRead2Item } from './ator-read2-datasource';

@Component({
  selector: 'app-ator-read2',
  templateUrl: './ator-read2.component.html',
  styleUrls: ['./ator-read2.component.css']
})
export class AtorRead2Component implements AfterViewInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<AtorRead2Item>;
  dataSource: AtorRead2DataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'name','action'];

  constructor() {
    this.dataSource = new AtorRead2DataSource();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }
}
