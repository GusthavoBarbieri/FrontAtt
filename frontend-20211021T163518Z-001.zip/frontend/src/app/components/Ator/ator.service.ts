import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from "@angular/material/snack-bar";
import { Observable, EMPTY } from "rxjs";
import { map, catchError } from "rxjs/operators";
import {Ator} from './ator.model';

@Injectable({
  providedIn: 'root'
})
export class AtorService {
  [x: string]: any;

  baseUrl = "http://localhost:4200/ator";

  constructor(private snackBar: MatSnackBar,private http: HttpClient) { }

  showMessage(msg: string): void {
    this.snackBar.open(msg, "X", {
      duration: 3000,
      horizontalPosition: "right",
      verticalPosition: "top",
     
    });
  }

  create(ator: Ator): Observable<Ator> {
    return this.http.post<Ator>(this.baseUrl, ator)
  }

  read(): Observable<Ator[]> {
    return this.http.get<Ator[]>(this.baseUrl);
  }

  readById(id: string): Observable<Ator>{
    const url = `${this.baseUrl}/${id}`;
    return this.http.get<Ator>(url).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  update(ator: Ator): Observable<Ator> {
    const url = `${this.baseUrl}/${ator.id}`;
    return this.http.put<Ator>(url, ator)
    
  }
  
  delete(id: number): Observable<Ator> {
    const url = `${this.baseUrl}/${id}`;
    return this.http.delete<Ator>(url).pipe(
      map((obj) => obj),
      catchError((e) => this.errorHandler(e))
    );
  }

  errorHandler(e: any): Observable<any> {
    this.showMessage("Ocorreu um erro!");
    return EMPTY;
  }
}
