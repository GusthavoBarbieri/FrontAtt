import { Ator } from './../ator.model';
import { Component, OnInit } from '@angular/core';
import { AtorService } from './../ator.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-ator-create',
  templateUrl: './ator-create.component.html',
  styleUrls: ['./ator-create.component.css']
})
export class AtorCreateComponent implements OnInit {

  ator: Ator = {
    id:0,
    name: '',
    
  }
  constructor(private atorService: AtorService,
    private router: Router) { }

  ngOnInit(): void {
  }
  
  createAtor(): void {
    this.atorService.create(this.ator).subscribe(() => {
      this.atorService.showMessage('Ator criado!')
      this.router.navigate(['/ator'])
    })
        
      }
  
      cancel():void{
          this.router.navigate(['/ator'])
        
  
      }

}
