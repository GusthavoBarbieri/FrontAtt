import { Component, OnInit } from '@angular/core';
import { Titulo, TituloTabela } from '../titulo.model';
import { TituloService } from '../titulo.service';

@Component({
  selector: 'app-titulo-read',
  templateUrl: './titulo-read.component.html',
  styleUrls: ['./titulo-read.component.css']
})
export class TituloReadComponent implements OnInit {

  titulo: Titulo[] = [];
  displayedColumns = ['id', 'nome','ano','sinopse','categoria','action'];

  
  ELEMENT_DATA: TituloTabela[] = [
    {id:1,name:'t1',ano:2020,sinopse:'teste',categoria:'terror',},
   
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private tituloService: TituloService) { 

  }

  ngOnInit(): void {
    this. tituloService.read().subscribe( titulo => {
      this. titulo =  titulo
      //console.log(products)
    })
  }
}
