import { Item } from './../item.model';
import { Component, OnInit } from '@angular/core';
import { ItemService } from '../item.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-item-create',
  templateUrl: './item-create.component.html',
  styleUrls: ['./item-create.component.css']
})
export class ItemCreateComponent implements OnInit {

  item: Item = {
    id:0,
    Nserie: 0,
    dataDeAq: new Date('2021-10-18'),
    tipoItem:'',
    
  }
  constructor(private itemService: ItemService,
    private router: Router) { }

  ngOnInit(): void {
  }
  
  createItem(): void {
    this.itemService.create(this.item).subscribe(() => {
      this.itemService.showMessage('Item criado!')
      this.router.navigate(['/item'])
    })
        
      }
  
      cancel():void{
          this.router.navigate(['/item'])
        
  
      }

}
