export interface Item {
    id: number
    Nserie: number
    dataDeAq: Date
    tipoItem:string
}