import { NgModule , LOCALE_ID } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './components/template/header/header.component';

import { MatToolbarModule } from '@angular/material/toolbar';
import { FooterComponent } from './components/template/footer/footer.component';
import { NavComponent } from './components/template/nav/nav.component';
import { MatSidenavModule } from  '@angular/material/sidenav';
import { MatCardModule } from  '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { HomeComponent } from './views/home/home.component';
import { ProductCrudComponent } from './views/product-crud/product-crud.component';
import { RedDirective } from './directives/red.directive';
import { ForDirective } from './directives/for.directive';
import { ProductCreateComponent } from './components/product/product-create/product-create.component';
import { MatButtonModule } from  '@angular/material/button';
import { MatSnackBarModule } from  '@angular/material/snack-bar';
import { HttpClientModule } from  '@angular/common/http';
import {ReactiveFormsModule} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ProductReadComponent } from './components/product/product-read/product-read.component';
import { ProductRead2Component } from './components/product/product-read2/product-read2.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import {MatSelectModule} from '@angular/material/select'; 
import localePt from '@angular/common/locales/pt';
import { registerLocaleData } from  '@angular/common';
import { AtorCrudComponent } from './views/ator-crud/ator-crud.component';
import { AtorCreateComponent } from './components/Ator/ator-create/ator-create.component';
import { AtorReadComponent } from './components/Ator/ator-read/ator-read.component';
import { AtorRead2Component } from './components/Ator/ator-read2/ator-read2.component';
import { DiretorCrudComponent } from './views/diretor-crud/diretor-crud.component';
import { ClasseCrudComponent } from './views/classe-crud/classe-crud.component';
import { ItemCrudComponent } from './views/item-crud/item-crud.component';
import { TituloCrudComponent } from './views/titulo-crud/titulo-crud.component';
import { DiretorCreateComponent } from './components/Diretor/diretor-create/diretor-create.component';
import { ClasseCreateComponent } from './components/Classe/classe-create/classe-create.component';
import { ItemCreateComponent } from './components/Item/item-create/item-create.component';
import { TituloCreateComponent } from './components/Titulo/titulo-create/titulo-create.component';
import { ClienteComponent } from './components/AtendimentoCliente/cliente/cliente.component';
import { LocacaoComponent } from './components/AtendimentoCliente/locacao/locacao.component';
import { DiretorReadComponent } from './components/Diretor/diretor-read/diretor-read.component';
import { ClasseReadComponent } from './components/Classe/classe-read/classe-read.component';
import { ItemReadComponent } from './components/Item/item-read/item-read.component';
import { ClienteCrudComponent } from './views/cliente-crud/cliente-crud.component';
import { LocacaoCrudComponent } from './views/locacao-crud/locacao-crud.component';
import { TituloReadComponent } from './components/Titulo/titulo-read/titulo-read.component';
import { DependenteCreateComponent } from './components/AtendimentoCliente/dependente-create/dependente-create.component';
import { AtorUpdateComponent } from './components/Ator/ator-update/ator-update.component';
import { ClasseUpdateComponent } from './components/Classe/classe-update/classe-update.component';
import { DiretorUpdateComponent } from './components/Diretor/diretor-update/diretor-update.component';
import { ItemUpdateComponent } from './components/Item/item-update/item-update.component';
import { TituloUpdateComponent } from './components/Titulo/titulo-update/titulo-update.component';
import { ClienteReadComponent } from './components/AtendimentoCliente/cliente/cliente-read/cliente-read.component';
import { ClienteUpdateComponent } from './components/AtendimentoCliente/cliente/cliente-update/cliente-update.component';
import { LocacaoUpdateComponent } from './components/AtendimentoCliente/locacao/locacao-update/locacao-update.component';
import { LocacaoReadComponent } from './components/AtendimentoCliente/locacao/locacao-read/locacao-read.component';
import { ConsultaCrudComponent } from './views/consulta-crud/consulta-crud.component';

registerLocaleData(localePt);


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    HomeComponent,
    ProductCrudComponent,
    RedDirective,
    ForDirective,
    ProductCreateComponent,
    ProductReadComponent,
    ProductRead2Component,
    AtorCrudComponent,
    AtorCreateComponent,
    AtorReadComponent,
    AtorRead2Component,
    DiretorCrudComponent,
    ClasseCrudComponent,
    ItemCrudComponent,
    TituloCrudComponent,
    DiretorCreateComponent,
    ClasseCreateComponent,
    ItemCreateComponent,
    TituloCreateComponent,
    LocacaoComponent,
    ClienteComponent,
    DiretorReadComponent,
    ClasseReadComponent,
    ItemReadComponent,
    ClienteCrudComponent,
    LocacaoCrudComponent,
    TituloReadComponent,
    DependenteCreateComponent,
    AtorUpdateComponent,
    ClasseUpdateComponent,
    DiretorUpdateComponent,
    ItemUpdateComponent,
    TituloUpdateComponent,
    ClienteReadComponent,
    ClienteUpdateComponent,
    LocacaoUpdateComponent,
    LocacaoReadComponent,
    ConsultaCrudComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatCardModule,
    MatSnackBarModule,
    MatButtonModule,
    HttpClientModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatSelectModule,
    ReactiveFormsModule
  ],
  providers:[{
    provide: LOCALE_ID,
    useValue: 'pt-BR'
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
