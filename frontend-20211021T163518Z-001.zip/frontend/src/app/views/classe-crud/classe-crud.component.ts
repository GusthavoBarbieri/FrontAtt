import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-classe-crud',
  templateUrl: './classe-crud.component.html',
  styleUrls: ['./classe-crud.component.css']
})
export class ClasseCrudComponent implements OnInit {

  constructor(private router: Router) {
    /* headerService.headerData = {
       title: 'Cadastro de Produtos',
       icon: 'storefront',
       routeUrl: '/products'
     }*/
   }

  ngOnInit(): void {
  }

  navigateToCreate(): void {
    this.router.navigate(['/classe/create'])
    //console.log("Navegando")
  }

  navigateToAlter(): void {
    this.router.navigate(['/classe/alter'])
    //console.log("Navegando")
  }
}
