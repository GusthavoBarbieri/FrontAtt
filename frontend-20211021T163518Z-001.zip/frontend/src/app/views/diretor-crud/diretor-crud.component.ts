import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-diretor-crud',
  templateUrl: './diretor-crud.component.html',
  styleUrls: ['./diretor-crud.component.css']
})
export class DiretorCrudComponent implements OnInit {

  constructor(private router: Router) {
    /* headerService.headerData = {
       title: 'Cadastro de Produtos',
       icon: 'storefront',
       routeUrl: '/products'
     }*/
   }

  ngOnInit(): void {
  }

  navigateToCreate(): void {
    this.router.navigate(['/diretor/create'])
    //console.log("Navegando")
  }
  navigateToAlter(): void {
    this.router.navigate(['/diretor/alter'])
    //console.log("Navegando")
  }
}
