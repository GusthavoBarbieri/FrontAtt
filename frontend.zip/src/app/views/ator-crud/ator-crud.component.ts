import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ator-crud',
  templateUrl: './ator-crud.component.html',
  styleUrls: ['./ator-crud.component.css']
})
export class AtorCrudComponent implements OnInit {

  constructor(private router: Router) {
    /* headerService.headerData = {
       title: 'Cadastro de Produtos',
       icon: 'storefront',
       routeUrl: '/products'
     }*/
   }

  ngOnInit(): void {
  }

  navigateToAtorCreate(): void {
    this.router.navigate(['/ator/create'])
    //console.log("Navegando")
  }
  navigateToAtorAlter(): void {
    this.router.navigate(['/ator/alter'])
    //console.log("Navegando")
  }

}
