import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-consulta-crud',
  templateUrl: './consulta-crud.component.html',
  styleUrls: ['./consulta-crud.component.css']
})
export class ConsultaCrudComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  navigateToC(): void {
    this.router.navigate(['/consulta/nome'])
    //console.log("Navegando")
  }
  navigateToCA(): void {
    this.router.navigate(['/consulta/ator'])
    //console.log("Navegando")
  }
  navigateToCC(): void {
    this.router.navigate(['/consulta/categoria'])
    //console.log("Navegando")
  }
}
