import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Titulo } from '../titulo.model';
import { TituloService } from '../titulo.service';

@Component({
  selector: 'app-titulo-update',
  templateUrl: './titulo-update.component.html',
  styleUrls: ['./titulo-update.component.css']
})
export class TituloUpdateComponent implements OnInit {
  toppings = new FormControl();
  toppingList: string[] = ['Ator1', 'Ator12', 'Roberto', 'Peroni'];
  titulo: Titulo;

  constructor(
    private tituloService: TituloService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    if(id != null){
      this.tituloService.readById(id).subscribe((titulo) => {
        this.titulo = titulo;
      });
    }
    

  }

  update(): void {
    this.tituloService.update(this.titulo).subscribe(() => {
      this.tituloService.showMessage("titulo atualizada com sucesso!");
      this.router.navigate(["/titulo"]);
    });

  }
  cancel(): void {
    this.router.navigate(["/titulo"]);
  }

}
