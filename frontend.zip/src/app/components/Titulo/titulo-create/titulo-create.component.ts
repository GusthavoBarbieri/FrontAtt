import { Item } from './../../Item/item.model';
import { Classe } from './../../Classe/classe.model';
import { Diretor } from './../../Diretor/diretor.model';
import { Ator } from './../../Ator/ator.model';
import { Titulo } from './../titulo.model';
import { Component, OnInit } from '@angular/core';
import { TituloService } from '../titulo.service';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-titulo-create',
  templateUrl: './titulo-create.component.html',
  styleUrls: ['./titulo-create.component.css']
})
export class TituloCreateComponent implements OnInit {
  toppings = new FormControl();
  toppingList: string[] = ['Ator1', 'Ator12', 'Roberto', 'Peroni'];

  classe: Classe = {
    id:0,
    name: '',
    valor: 0.0,
    prazoDeDevolucao: 0,
    
  }
  ator: Ator = {
    id:0,
    name: '',
    
  }
  diretor: Diretor = {
    id:0,
    name: '',
    
  }
  

  titulo: Titulo = {
    name: '',
    ano:0,
    sinopse:'',
    categoria:'',
    ator: this.ator,
    diretor : this.diretor,
    classe: this.classe,
    
    
  }

  
  constructor(private tituloService: TituloService,
    private router: Router) { }

   
  ngOnInit(): void {
    
  }
  
  createClasse(): void {
   this.tituloService.create(this.titulo).subscribe(() => {
      this.tituloService.showMessage('titulo criado!')
      this.router.navigate(['/titulo'])
    })
    //this.router.navigate(['/classe'])  
      }
  
      cancel():void{
          this.router.navigate(['/titulo'])
        
  
      }
}
