import { Classe } from './../Classe/classe.model';
import { Diretor } from './../Diretor/diretor.model';
import { Ator } from './../Ator/ator.model';
import { Item } from '../Item/item.model';

export interface Titulo {
    id?: number
    name: string
    ano:number
    sinopse:string
    categoria:string
    ator : Ator
    diretor : Diretor
    classe:Classe
   
}

export interface TituloTabela {
    id?: number
    name: string
    ano:number
    sinopse:string
    categoria:string
   
}