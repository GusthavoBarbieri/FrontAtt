import { Classe } from './../classe.model';
import { Component, OnInit } from '@angular/core';
import { ClasseService } from '../classe.service';

@Component({
  selector: 'app-classe-read',
  templateUrl: './classe-read.component.html',
  styleUrls: ['./classe-read.component.css']
})
export class ClasseReadComponent implements OnInit {

  classe: Classe[] = [];
  displayedColumns = ['id', 'name','valor','prazo','action'];
  ELEMENT_DATA: Classe[] = [
    {id: 1,name: 'Hydrogen',valor:1,prazoDeDevolucao:120},
    {id: 2,name: 'Helium',valor:1,prazoDeDevolucao:120},
    {id: 4,name: 'Lithium',valor:1,prazoDeDevolucao:120},
    {id: 5,name: 'Beryllium',valor:1,prazoDeDevolucao:120},
    {id: 6,name: 'Boron',valor:1,prazoDeDevolucao:120},
    {id: 7,name: 'Carbon',valor:1,prazoDeDevolucao:120},
    {id: 8,name: 'Nitrogen',valor:1,prazoDeDevolucao:120},
    {id: 9,name: 'Oxygen',valor:1,prazoDeDevolucao:120},
    {id: 10,name: 'Fluorine',valor:1,prazoDeDevolucao:120},
    {id: 11,name: 'Neon',valor:1,prazoDeDevolucao:120},
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private classeService: ClasseService) { 

  }

  ngOnInit(): void {
    this. classeService.read().subscribe( classe => {
      this. classe =  classe
      //console.log(products)
    })
  }
}
