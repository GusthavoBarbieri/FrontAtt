export interface Diretor {
    id: number
    name: string
}