import { Diretor } from './../diretor.model';
import { Component, OnInit } from '@angular/core';

import { DiretorService } from '../diretor.service';

@Component({
  selector: 'app-diretor-read',
  templateUrl: './diretor-read.component.html',
  styleUrls: ['./diretor-read.component.css']
})
export class DiretorReadComponent implements OnInit {

  diretor: Diretor[] = [];
  displayedColumns = ['id', 'name','action'];
  ELEMENT_DATA: Diretor[] = [
    {id: 1,name: 'Hydrogen'},
    {id: 2,name: 'Helium'},
    {id: 4,name: 'Lithium'},
    {id: 5,name: 'Beryllium'},
    {id: 6,name: 'Boron'},
    {id: 7,name: 'Carbon'},
    {id: 8,name: 'Nitrogen'},
    {id: 9,name: 'Oxygen'},
    {id: 10,name: 'Fluorine'},
    {id: 11,name: 'Neon'},
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private diretorService: DiretorService) { 

  }

  ngOnInit(): void {
    this. diretorService.read().subscribe( diretor => {
      this. diretor =  diretor
      //console.log(products)
    })
  }

}
