import { Diretor } from './../diretor.model';
import { Component, OnInit } from '@angular/core';
import { DiretorService } from '../diretor.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-diretor-update',
  templateUrl: './diretor-update.component.html',
  styleUrls: ['./diretor-update.component.css']
})
export class DiretorUpdateComponent implements OnInit {

  diretor: Diretor;

  constructor(
    private diretorService: DiretorService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    if(id != null){
      this.diretorService.readById(id).subscribe((diretor) => {
        this.diretor = diretor;
      });
    }
    

  }

  update(): void {
    this.diretorService.update(this.diretor).subscribe(() => {
      this.diretorService.showMessage("diretor atualizado com sucesso!");
      this.router.navigate(["/diretor"]);
    });

  }
  cancel(): void {
    this.router.navigate(["/diretor"]);
  }

}
