import { Dependente } from './../cliente/cliente.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from "@angular/material/snack-bar";
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DependenteCreateService {

  baseUrl = "http://localhost:4200/ator";

  constructor(private snackBar: MatSnackBar,private http: HttpClient) { }

  showMessage(msg: string): void {
    this.snackBar.open(msg, "X", {
      duration: 3000,
      horizontalPosition: "right",
      verticalPosition: "top",
     
    });
  }

  create(cliente: Dependente): Observable<Dependente> {
    return this.http.post<Dependente>(this.baseUrl, cliente)
  }

  read(): Observable<Dependente[]> {
    return this.http.get<Dependente[]>(this.baseUrl);
  }
}
