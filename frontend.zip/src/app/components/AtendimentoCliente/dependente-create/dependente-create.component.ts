import { Component, OnInit } from '@angular/core';
import { Dependente } from '../cliente/cliente.model';
import { Router } from '@angular/router';
import { DependenteCreateService } from './dependente-create.service';
@Component({
  selector: 'app-dependente-create',
  templateUrl: './dependente-create.component.html',
  styleUrls: ['./dependente-create.component.css']
})
export class DependenteCreateComponent implements OnInit {
  cliente:Dependente ={
    id:0,
    name: '',
    sexo:'',
    ativo:0,
  }
  constructor(private clienteService: DependenteCreateService,
    private router: Router) { }

  ngOnInit(): void {
  }

  create(): void {
    this.clienteService.create(this.cliente).subscribe(() => {
      this.clienteService.showMessage('Dependente criado!')
      this.router.navigate(['/cliente'])
    })
        
      }
  
      cancel():void{
          this.router.navigate(['/cliente'])
        
  
      }

}
