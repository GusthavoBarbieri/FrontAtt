import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-consulta-nome',
  templateUrl: './consulta-nome.component.html',
  styleUrls: ['./consulta-nome.component.css']
})
export class ConsultaNomeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  cancel():void{
    this.router.navigate(['/consulta'])
}
}
