import { Locacao } from './../locacao/locacao.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cliente, Dependente } from './cliente.model';
import { ClienteService } from './cliente.service';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.css']
})
export class ClienteComponent implements OnInit {

  dependente:Dependente ={
    id:0,
    name: '',
    sexo:'',
    ativo:0,
  }
  cliente: Cliente = {
    id:0,
    name: '',
    sexo:'',
    cpf:'',
    endereco:'',
    tel:'',
    ativo:0,
    dependente:this.dependente,
    locacao: new Array<Locacao>(),
    
  }
  toppings = new FormControl();
  toppingList: string[] = ['D1', 'D112', 'D1', 'D100'];
  constructor(private clienteService: ClienteService,
    private router: Router) { }

  ngOnInit(): void {
  }
  
  create(): void {
    this.clienteService.create(this.cliente).subscribe(() => {
      this.clienteService.showMessage('cliente criado!')
      this.router.navigate(['/cliente'])
    })
        
      }
  
      cancel():void{
          this.router.navigate(['/cliente'])
        
  
      }

}
