import { Locacao } from './../locacao/locacao.model';
export interface Cliente {
    id: number
    name: string
    sexo:string
    cpf:string
    endereco:string
    tel:string
    ativo:number
    dependente:Dependente
    locacao: Array<Locacao>
}

export interface Dependente {
    id: number
    name: string
    sexo:string
    ativo:number
    
}

export interface ClienteT {
    id: number
    name: string
    sexo:string
    cpf:string
    endereco:string
    tel:string
    ativo:number

}