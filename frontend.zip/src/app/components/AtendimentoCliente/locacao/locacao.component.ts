import { Cliente, Dependente } from './../cliente/cliente.model';
import { Locacao } from './locacao.model';
import { Component, OnInit } from '@angular/core';
import { LocacaoService } from './locacao.service';
import { Router } from '@angular/router';
import { Item } from '../../Item/item.model';
import { Titulo } from '../../Titulo/titulo.model';

@Component({
  selector: 'app-locacao',
  templateUrl: './locacao.component.html',
  styleUrls: ['./locacao.component.css']
})
export class LocacaoComponent implements OnInit {
  dependente:Dependente ={
    id:0,
    name: '',
    sexo:'',
    ativo:0,
  }

  cliente: Cliente = {
    id:0,
    name: '',
    sexo:'',
    cpf:'',
    endereco:'',
    tel:'',
    ativo:0,
    dependente:this.dependente,
    locacao: new Array<Locacao>(),
    
  }
  item: Item = {
    id:0,
    Nserie: 0,
    dataDeAq: '',
    tipoItem:'',
    titulo: new Array<Titulo>()
    
  }
  locacao: Locacao = {
    id:0,
    dataLo: '',
    dataPrevista: '',
    dataEfetiva: '',
    valor:0,
    multa:0,
    cliente: this.cliente,
    item:this.item,
    
  }
  constructor(private locacaoService: LocacaoService,
    private router: Router) { }

  ngOnInit(): void {
  }
  
  create(): void {
    this.locacaoService.create(this.locacao).subscribe(() => {
      this.locacaoService.showMessage('locacao criado!')
      this.router.navigate(['/locacao'])
    })
        
      }
  
      cancel():void{
          this.router.navigate(['/locacao'])
        
  
      }
}
