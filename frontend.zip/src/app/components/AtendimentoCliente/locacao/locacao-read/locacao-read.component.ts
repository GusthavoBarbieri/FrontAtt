import { Locacao, LocacaoT } from './../locacao.model';
import { Component, OnInit } from '@angular/core';
import { LocacaoService } from '../locacao.service';

@Component({
  selector: 'app-locacao-read',
  templateUrl: './locacao-read.component.html',
  styleUrls: ['./locacao-read.component.css']
})
export class LocacaoReadComponent implements OnInit {
  locacao: Locacao[] = [];
  displayedColumns = ['id', 'datal','datap','dataf', 'valor','multa','item','action'];
  ELEMENT_DATA: LocacaoT[] = [
    {id: 1,dataLo:'16-10-2021',dataEfetiva:'',dataPrevista:'18-10-2021',valor:100,multa:0,INserie:"1897887"},
    {id: 2,dataLo:'18-10-2021',dataEfetiva:'28-10-2021',dataPrevista:'18-10-2021',valor:150,multa:100,INserie:"42457"},
    {id: 4,dataLo:'',dataEfetiva:'',dataPrevista:'',valor:150,multa:0,INserie:"123"}
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private locacaoService: LocacaoService) { 

  }

  ngOnInit(): void {
    this. locacaoService.read().subscribe( locacao => {
      this. locacao =  locacao
      //console.log(products)
    })
  }

  
}
