import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Locacao } from '../locacao.model';
import { LocacaoService } from '../locacao.service';

@Component({
  selector: 'app-locacao-update',
  templateUrl: './locacao-update.component.html',
  styleUrls: ['./locacao-update.component.css']
})
export class LocacaoUpdateComponent implements OnInit {

 
  locacao: Locacao;

  constructor(
    private locacaoService: LocacaoService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    if(id != null){
      this.locacaoService.readById(id).subscribe((locacao) => {
        this.locacao = locacao;
      });
    }
    

  }

  update(): void {
    this.locacaoService.update(this.locacao).subscribe(() => {
      this.locacaoService.showMessage("locacao atualizada com sucesso!");
      this.router.navigate(["/locacao"]);
    });

  }
  cancel(): void {
    this.router.navigate(["/locacao"]);
  }
}
