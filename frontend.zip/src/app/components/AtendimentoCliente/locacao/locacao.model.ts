import { Item } from '../../Item/item.model';
import { Cliente } from './../cliente/cliente.model';
export interface Locacao {
    id: number
    dataLo:string
    dataPrevista:string
    dataEfetiva:string
    valor:number
    multa:number
    cliente: Cliente
    item: Item
}

export interface LocacaoT {
    id: number
    dataLo:string
    dataPrevista:string
    dataEfetiva:string
    valor:number
    multa:number
    INserie:String

}