import { Titulo } from "../Titulo/titulo.model";

export interface Item {
    id: number
    Nserie: number
    dataDeAq: string
    tipoItem:string
    titulo:Array<Titulo>
}

export interface ItemT {
    id: number
    Nserie: number
    dataDeAq: string
    tipoItem:string
}