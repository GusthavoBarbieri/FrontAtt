import { ItemT } from './../item.model';
import { Component, OnInit } from '@angular/core';
import { Item } from '../item.model';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-item-read',
  templateUrl: './item-read.component.html',
  styleUrls: ['./item-read.component.css']
})
export class ItemReadComponent implements OnInit {

  item: Item[] = [];
  displayedColumns = ['id', 'numero','data','tipo','action'];
  ELEMENT_DATA: ItemT[] = [
    {id: 1,Nserie:20,dataDeAq:'11/10/2021',tipoItem:'1'},
    {id: 1,Nserie:20,dataDeAq:'11/10/2021',tipoItem:'3'},
    {id: 1,Nserie:20,dataDeAq:'11/10/2021',tipoItem:'2'},
   
  ];
  dataSource = this.ELEMENT_DATA;
  constructor(private itemService: ItemService) { 

  }

  ngOnInit(): void {
    this. itemService.read().subscribe( item => {
      this. item =  item
      //console.log(products)
    })
  }

}
