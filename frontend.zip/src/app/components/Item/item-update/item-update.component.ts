import { Item } from './../item.model';
import { Component, OnInit } from '@angular/core';
import { ItemService } from '../item.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-item-update',
  templateUrl: './item-update.component.html',
  styleUrls: ['./item-update.component.css']
})
export class ItemUpdateComponent implements OnInit {

  item:Item;

  constructor(
    private itemService: ItemService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    if(id != null){
      this.itemService.readById(id).subscribe((classe) => {
        this.item = classe;
      });
    }
    

  }

  update(): void {
    this.itemService.update(this.item).subscribe(() => {
      this.itemService.showMessage("item atualizado com sucesso!");
      this.router.navigate(["/item"]);
    });

  }
  cancel(): void {
    this.router.navigate(["/item"]);
  }
}
