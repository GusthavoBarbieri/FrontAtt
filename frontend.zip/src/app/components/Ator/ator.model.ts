export interface Ator {
    id: number
    name: string
}